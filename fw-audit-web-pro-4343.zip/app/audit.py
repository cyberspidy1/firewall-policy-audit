
import io
from datetime import datetime
from typing import Dict, List, Tuple
import pandas as pd
from openpyxl.styles import PatternFill, Font
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, Reference

# Column names expected from your CSVs
COL_NAME = "Name"
COL_ACTION = "Action"
COL_ENABLED = "Name"   # we'll parse "[Disabled]" from Name
COL_SOURCE_ZONE = "Source Zone"
COL_DEST_ZONE = "Destination Zone"
COL_SOURCE_ADDR = "Source Address"
COL_DEST_ADDR = "Destination Address"
COL_APP = "Application"
COL_SERVICE = "Service"
COL_PROFILE = "Profile"
COL_TAGS = "Tags"
COL_HITS = "Rule Usage Hit Count"
COL_LAST_HIT = "Rule Usage Last Hit"
COL_FIRST_HIT = "Rule Usage First Hit"

AUDIT_COL = "Audit Finding"

CATEGORIES = [
    "Redundant/Disabled",
    "Overly Permissive",
    "Unused/Stale",
    "No Security Profiles",
    "Temp/Test Rules",
    "Shadow/Overlapping",
    "Legacy Rules",
    "Logging Gaps"
]

COLOR_MAP = {
    "Redundant/Disabled": "FFC7CE",
    "Overly Permissive": "FFEB9C",
    "Unused/Stale": "C6EFCE",
    "No Security Profiles": "F8CBAD",
    "Temp/Test Rules": "C9C9FF",
    "Shadow/Overlapping": "C5D9F1",
    "Legacy Rules": "D9D2E9",
    "Logging Gaps": "DDEBF7",
}

def _parse_date(val: str):
    if not isinstance(val, str):
        return None
    val = val.strip()
    if val in ("-", "", "nan", "NaT"):
        return None
    # Try multiple formats
    fmts = ["%m/%d/%Y %H:%M", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y", "%d/%m/%Y %H:%M", "%Y-%m-%d %H:%M:%S"]
    for f in fmts:
        try:
            return datetime.strptime(val, f)
        except Exception:
            continue
    # If Excel-like / already parsed
    try:
        return pd.to_datetime(val)
    except Exception:
        return None

def _any_str(cell: str, targets: List[str]) -> bool:
    s = str(cell).lower()
    return any(t in s for t in targets)

def _is_disabled(name: str) -> bool:
    return str(name).strip().lower().startswith("[disabled]")

def _is_over_permissive(app: str, service: str, src_addr: str, dst_addr: str) -> bool:
    return ("any" in str(app).lower() or "any" in str(service).lower()) and \
           ("any" in str(src_addr).lower() or "any" in str(dst_addr).lower())

def _is_no_security_profile(profile: str, action: str, dest_zone: str, require_profiles_to_wan: bool) -> bool:
    has_profile = str(profile).strip().lower() not in ("", "none", "nan")
    if has_profile:
        return False
    if str(action).lower() != "allow":
        return False
    if not require_profiles_to_wan:
        return True  # Still flag as guidance if allowed without profiles
    # Require when to WAN is present
    return "wan" in str(dest_zone).lower()

def _is_temp_rule(name: str, tags: str) -> bool:
    return _any_str(name, ["temp", "poc", "test"]) or _any_str(tags, ["temp", "poc", "test"])

def _is_legacy(first_hit: str, last_hit: str, legacy_year: int) -> bool:
    d_first = _parse_date(first_hit)
    d_last = _parse_date(last_hit)
    # If both dates exist and both are old (first seen and last seen prior to legacy_year)
    if d_first and d_first.year <= legacy_year and (not d_last or d_last.year <= legacy_year):
        return True
    # If no hits at all and first seen is old
    if (not d_last) and d_first and d_first.year <= legacy_year:
        return True
    return False

def _is_stale(last_hit: str, stale_months: int) -> bool:
    d_last = _parse_date(last_hit)
    if not d_last:
        return True  # never hit
    delta_months = (datetime.now() - d_last).days / 30.0
    return delta_months >= stale_months

def _has_logging_gap(options: str, profile: str) -> bool:
    # If options do not include "Traffic log sent" or profile is 'none', treat as potential gap
    s = str(options).lower()
    return "traffic log sent" not in s

def _shadow_pairs(df: pd.DataFrame) -> List[Tuple[str, str]]:
    # Very simple heuristic: same zone-pair & permissive rule that "any" addresses can shadow specific ones.
    pairs = []
    try:
        a = df[[COL_NAME, COL_SOURCE_ZONE, COL_DEST_ZONE, COL_SOURCE_ADDR, COL_DEST_ADDR, COL_APP, COL_SERVICE]].fillna("")
    except KeyError:
        return pairs
    for i, r1 in a.iterrows():
        if "any" not in str(r1[COL_APP]).lower() and "any" not in str(r1[COL_SERVICE]).lower():
            continue
        for j, r2 in a.iterrows():
            if i == j:
                continue
            if str(r1[COL_SOURCE_ZONE]).lower() == str(r2[COL_SOURCE_ZONE]).lower() and \
               str(r1[COL_DEST_ZONE]).lower() == str(r2[COL_DEST_ZONE]).lower():
                if "any" in str(r1[COL_SOURCE_ADDR]).lower() and "any" in str(r1[COL_DEST_ADDR]).lower():
                    # r1 is super-permissive; r2 likely shadowed
                    pairs.append((r1[COL_NAME], r2[COL_NAME]))
    # Dedup
    seen = set()
    out = []
    for p in pairs:
        if p not in seen:
            out.append(p)
            seen.add(p)
    return out

def run_audit(df: pd.DataFrame, settings: Dict) -> bytes:
    stale_months = int(settings.get("stale_months", 6))
    legacy_year = int(settings.get("legacy_year", 2022))
    top_risky_count = int(settings.get("top_risky_count", 50))
    require_profiles_to_wan = bool(settings.get("require_profiles_to_wan", True))

    # Ensure columns exist
    for col in [COL_NAME, COL_ACTION, COL_SOURCE_ZONE, COL_DEST_ZONE, COL_SOURCE_ADDR,
                COL_DEST_ADDR, COL_APP, COL_SERVICE, COL_PROFILE, COL_TAGS, COL_HITS, COL_LAST_HIT, COL_FIRST_HIT]:
        if col not in df.columns:
            df[col] = ""

    findings = []
    for _, row in df.iterrows():
        name = row[COL_NAME]
        tags = row[COL_TAGS]
        profile = row[COL_PROFILE]
        action = row[COL_ACTION]
        dest_zone = row[COL_DEST_ZONE]
        src_addr = row[COL_SOURCE_ADDR]
        dst_addr = row[COL_DEST_ADDR]
        app = row[COL_APP]
        svc = row[COL_SERVICE]
        last_hit = row[COL_LAST_HIT]
        first_hit = row[COL_FIRST_HIT]

        cats = []
        if _is_disabled(name):
            cats.append("Redundant/Disabled")
        if _is_over_permissive(app, svc, src_addr, dst_addr):
            cats.append("Overly Permissive")
        if _is_stale(last_hit, stale_months):
            cats.append("Unused/Stale")
        if _is_no_security_profile(profile, action, dest_zone, require_profiles_to_wan):
            cats.append("No Security Profiles")
        if _is_temp_rule(name, tags):
            cats.append("Temp/Test Rules")
        if _is_legacy(first_hit, last_hit, legacy_year):
            cats.append("Legacy Rules")
        # Logging gaps read from Options column if present
        options_col = "Options"
        options = row.get(options_col, "") if options_col in df.columns else ""
        if _has_logging_gap(options, profile):
            cats.append("Logging Gaps")

        findings.append("; ".join(sorted(set(cats))))

    df[AUDIT_COL] = findings

    # Shadow pairs
    pairs = _shadow_pairs(df)
    shadow_rows = []
    for p in pairs:
        shadow_rows.append({"Shadower": p[0], "Potentially Shadowed": p[1]})
    df_shadow = pd.DataFrame(shadow_rows)
    # Mark any that appear in df
    if not df_shadow.empty:
        df.loc[df[COL_NAME].isin(df_shadow["Potentially Shadowed"]), AUDIT_COL] = \
            (df.loc[df[COL_NAME].isin(df_shadow["Potentially Shadowed"]), AUDIT_COL] + "; Shadow/Overlapping").str.strip("; ")

    # Risk score (simple heuristic)
    def risk_score(row):
        score = 0
        if "Overly Permissive" in row[AUDIT_COL]: score += 5
        if "No Security Profiles" in row[AUDIT_COL]: score += 4
        if "Unused/Stale" in row[AUDIT_COL]: score += 3
        if "Redundant/Disabled" in row[AUDIT_COL]: score += 2
        if "Legacy Rules" in row[AUDIT_COL]: score += 2
        if "Temp/Test Rules" in row[AUDIT_COL]: score += 1
        return score
    df["_RiskScore"] = df.apply(risk_score, axis=1)

    # Build category sheets
    cat_frames = {cat: df[df[AUDIT_COL].str.contains(cat, na=False)].copy() for cat in CATEGORIES}

    # Summary counts
    summary_rows = [{"Category": cat, "Count": len(cat_frames[cat])} for cat in CATEGORIES]
    df_summary = pd.DataFrame(summary_rows)
    df_top = df.sort_values("_RiskScore", ascending=False).head(top_risky_count)

    # Hygiene sheet (quick checks)
    hygiene = []
    for _, r in df.iterrows():
        if ("any" in str(r.get(COL_SERVICE, "")).lower() and str(r.get(COL_ACTION, "")).lower()=="allow"):
            hygiene.append({"Rule": r[COL_NAME], "Issue": "Allows any service"})
        if ("rdp" in str(r.get(COL_SERVICE, "")).lower() or "tcp_3389" in str(r.get(COL_SERVICE, "")).lower()) and "wan" in str(r.get(COL_DEST_ZONE,"")).lower():
            hygiene.append({"Rule": r[COL_NAME], "Issue": "RDP allowed towards WAN"})
    df_hygiene = pd.DataFrame(hygiene)

    # Excel writer
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        # Main sheet
        df.drop(columns=["_RiskScore"], errors="ignore").to_excel(writer, index=False, sheet_name="All_Rules")
        wb = writer.book
        ws = writer.sheets["All_Rules"]

        # Color rows by primary category (first in AUDIT_COL)
        for i in range(2, ws.max_row + 1):
            finding_cell = ws.cell(row=i, column=list(df.columns).index(AUDIT_COL)+1)
            primary = (finding_cell.value or "").split(";")[0].strip()
            if primary in COLOR_MAP:
                fill = PatternFill(start_color=COLOR_MAP[primary], end_color=COLOR_MAP[primary], fill_type="solid")
                for j in range(1, ws.max_column + 1):
                    ws.cell(row=i, column=j).fill = fill

        # Auto width
        for col in range(1, ws.max_column + 1):
            ws.column_dimensions[get_column_letter(col)].width = 22

        # Category sheets
        for cat, cdf in cat_frames.items():
            cdf = cdf.drop(columns=["_RiskScore"], errors="ignore")
            cdf.to_excel(writer, index=False, sheet_name=cat.replace("/", "_"))
            wsc = writer.sheets[cat.replace("/", "_")]
            for col in range(1, wsc.max_column + 1):
                wsc.column_dimensions[get_column_letter(col)].width = 22

        # Shadow pairs
        if not df_shadow.empty:
            df_shadow.to_excel(writer, index=False, sheet_name="Shadow_Overlap")
            wss = writer.sheets["Shadow_Overlap"]
            for col in range(1, wss.max_column + 1):
                wss.column_dimensions[get_column_letter(col)].width = 30

        # Hygiene
        if not df_hygiene.empty:
            df_hygiene.to_excel(writer, index=False, sheet_name="Hygiene_Issues")
            wsh = writer.sheets["Hygiene_Issues"]
            for col in range(1, wsh.max_column + 1):
                wsh.column_dimensions[get_column_letter(col)].width = 30

        # Top high risk
        df_top.drop(columns=["_RiskScore"], errors="ignore").to_excel(writer, index=False, sheet_name="Top_High_Risk")
        wst = writer.sheets["Top_High_Risk"]
        for col in range(1, wst.max_column + 1):
            wst.column_dimensions[get_column_letter(col)].width = 22

        # Summary + chart
        df_summary.to_excel(writer, index=False, sheet_name="Summary")
        wsum = writer.sheets["Summary"]
        for col in range(1, wsum.max_column + 1):
            wsum.column_dimensions[get_column_letter(col)].width = 28

        # Bar chart
        if len(df_summary) >= 1:
            chart = BarChart()
            chart.title = "Audit Findings by Category"
            data = Reference(wsum, min_col=2, min_row=1, max_row=len(df_summary)+1)
            cats = Reference(wsum, min_col=1, min_row=2, max_row=len(df_summary)+1)
            chart.add_data(data, titles_from_data=True)
            chart.set_categories(cats)
            chart.y_axis.title = "Count"
            chart.x_axis.title = "Category"
            wsum.add_chart(chart, "D2")

    return output.getvalue()
