
import os

# Core app config
PORT = int(os.getenv("PORT", "4343"))
HOST = os.getenv("HOST", "0.0.0.0")

# Auth (optional)
REQUIRE_LOGIN = os.getenv("REQUIRE_LOGIN", "false").lower() == "true"
SESSION_SECRET = os.getenv("SESSION_SECRET", "change-me")
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASS = os.getenv("ADMIN_PASS", "admin123")

# Optional Azure SAML (scaffold only)
USE_SAML = os.getenv("USE_SAML", "false").lower() == "true"
SAML_ENTITY_ID = os.getenv("SAML_ENTITY_ID", "")
SAML_ACS_URL = os.getenv("SAML_ACS_URL", "")
SAML_METADATA_URL = os.getenv("SAML_METADATA_URL", "")
SAML_X509_CERT = os.getenv("SAML_X509_CERT", "")

# Defaults & thresholds (also configurable via UI)
DEFAULT_STALE_MONTHS = int(os.getenv("STALE_MONTHS", "6"))
DEFAULT_LEGACY_YEAR = int(os.getenv("LEGACY_YEAR", "2022"))
DEFAULT_TOP_RISKY_COUNT = int(os.getenv("TOP_RISKY_COUNT", "50"))
DEFAULT_REQUIRE_PROFILES_TO_WAN = os.getenv("REQUIRE_PROFILES_TO_WAN", "true").lower() == "true"
