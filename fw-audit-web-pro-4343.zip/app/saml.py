
# Scaffold only. If you enable USE_SAML, wire the python3-saml config here.
# For production, complete the OneLogin SAML toolkit settings and ACS/metadata routes.
from fastapi import APIRouter
router = APIRouter()

@router.get("/saml/metadata")
def saml_metadata():
    return {"status": "SAML metadata endpoint (scaffold)"}  # replace with real XML

@router.post("/sso/acs")
def saml_acs():
    return {"status": "SAML ACS endpoint (scaffold)"}  # implement assertion handling
