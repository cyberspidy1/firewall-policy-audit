
import io, zipfile
from typing import List, Optional
import pandas as pd
from fastapi import FastAPI, Request, UploadFile, Form
from fastapi.responses import HTMLResponse, StreamingResponse, RedirectResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .audit import run_audit
from .config import (PORT, HOST, REQUIRE_LOGIN, DEFAULT_STALE_MONTHS,
                     DEFAULT_LEGACY_YEAR, DEFAULT_TOP_RISKY_COUNT,
                     DEFAULT_REQUIRE_PROFILES_TO_WAN)
from .auth import add_session, is_authed, do_login, do_logout
from . import saml

app = FastAPI(title="FW Audit Web", version="1.0.0")
add_session(app)

app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")
app.include_router(saml.router)

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    if not is_authed(request):
        return templates.TemplateResponse("login.html", {"request": request, "require_login": REQUIRE_LOGIN})
    return templates.TemplateResponse("index.html", {
        "request": request,
        "defaults": {
            "stale_months": DEFAULT_STALE_MONTHS,
            "legacy_year": DEFAULT_LEGACY_YEAR,
            "top_risky_count": DEFAULT_TOP_RISKY_COUNT,
            "require_profiles_to_wan": DEFAULT_REQUIRE_PROFILES_TO_WAN
        }
    })

@app.post("/login")
async def login(request: Request, username: str = Form(...), password: str = Form(...)):
    if do_login(request, username, password):
        return RedirectResponse(url="/", status_code=303)
    return PlainTextResponse("Invalid credentials", status_code=401)

@app.get("/logout")
async def logout(request: Request):
    do_logout(request)
    return RedirectResponse(url="/", status_code=303)

@app.post("/audit")
async def audit(request: Request,
                files: List[UploadFile],
                stale_months: int = Form(DEFAULT_STALE_MONTHS),
                legacy_year: int = Form(DEFAULT_LEGACY_YEAR),
                top_risky_count: int = Form(DEFAULT_TOP_RISKY_COUNT),
                require_profiles_to_wan: Optional[bool] = Form(DEFAULT_REQUIRE_PROFILES_TO_WAN)):
    if not is_authed(request):
        return RedirectResponse(url="/", status_code=303)

    settings = {
        "stale_months": stale_months,
        "legacy_year": legacy_year,
        "top_risky_count": top_risky_count,
        "require_profiles_to_wan": bool(require_profiles_to_wan),
    }

    outputs = []
    for f in files:
        content = await f.read()
        name = f.filename or "input.xlsx"
        # Detect CSV vs Excel
        try:
            if name.lower().endswith(".csv"):
                df = pd.read_csv(io.BytesIO(content))
            else:
                df = pd.read_excel(io.BytesIO(content))
        except Exception:
            # fallback: attempt csv with latin-1
            df = pd.read_csv(io.BytesIO(content), encoding="latin-1")

        audited = run_audit(df, settings)
        out_name = (name.rsplit(".", 1)[0]) + "_AUDITED.xlsx"
        outputs.append((out_name, audited))

    if len(outputs) == 1:
        fname, data = outputs[0]
        return StreamingResponse(io.BytesIO(data),
                                 media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                 headers={"Content-Disposition": f'attachment; filename="{fname}"'})
    # Zip multiple
    zip_buf = io.BytesIO()
    with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for fname, data in outputs:
            zf.writestr(fname, data)
    zip_buf.seek(0)
    return StreamingResponse(zip_buf, media_type="application/zip",
                             headers={"Content-Disposition": 'attachment; filename="audited_results.zip"'})
