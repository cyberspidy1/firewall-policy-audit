
from fastapi import Request, Response, HTTPException
from starlette.middleware.sessions import SessionMiddleware
from .config import REQUIRE_LOGIN, ADMIN_USER, ADMIN_PASS, SESSION_SECRET

def add_session(app):
    app.add_middleware(SessionMiddleware, secret_key=SESSION_SECRET)

def is_authed(request: Request) -> bool:
    if not REQUIRE_LOGIN:
        return True
    return bool(request.session.get("user"))

def do_login(request: Request, username: str, password: str) -> bool:
    if username == ADMIN_USER and password == ADMIN_PASS:
        request.session["user"] = username
        return True
    return False

def do_logout(request: Request):
    request.session.clear()
